Set your computer time to 18:00 4/11/2020 before doing test
