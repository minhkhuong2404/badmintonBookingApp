package app.booking.api.PostHandler;

import lombok.Value;

@Value
class Response {
    String id;
}