package app.booking.api.Handler;

import lombok.Value;

@Value
class Response {
    String id;
}