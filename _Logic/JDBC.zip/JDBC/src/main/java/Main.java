
import app.booking.slot.Booking;
import app.booking.slot.CourtSlot;
import app.booking.slot.Slot;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.types.User;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        CourtSlot a = new CourtSlot();

//        // get
//        ArrayList<Slot> slotList = new ArrayList<Slot>(a.get(bookingList));
//        System.out.println("Done.");

    }

}
