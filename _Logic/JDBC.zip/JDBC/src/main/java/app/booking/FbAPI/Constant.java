package app.booking.FbAPI;

public class Constant {
    public static final String REDIRECT_URI
            = "http://localhost:8080/facebookfriends/FriendsListServlet";

    public static final String MY_ACCESS_TOKEN = "EAAPGlWsumGoBABtSnZAJ5wcb7UFT6GtZAfQVqx5an6wS7abZCBUYJtJGMarawyNRGyxAmvAHEQtgyJ9w4KQZABntr4Llx7KswaLZB0KYX1J4lumZCz4CinJ0HDkVnDpI6lgSI1NAq3fNZBulZBaL6EDrYir8I9mfRmwVYDZB97yg5xM1O7uB35rDZCZCISO6HPr8NpUu7W3PCoRMVI3OyL65RJzhoZBZCb0PBFHIO0I3Yhx5OFFIHsbYv5jtqFAyxmYTTvQUZD";

    // Facebook App
    public static final String MY_APP_ID = "1062769980774506";
    public static final String MY_APP_SECRET = "<your app secret>";
}
